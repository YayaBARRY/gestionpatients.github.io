package gestion.des.patients;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 * Servlet implementation class Index
 */
@WebServlet("/Index")
public class Index extends HttpServlet {
	
		private static final long serialVersionUID = 1L;
	       
			public void doPost(HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {

				String userName = request.getParameter("userName");
				String password = request.getParameter("password");

				if (userName.equals("Yaya") && password.equals("BARRY")) {
					response.sendRedirect("PatientManager.jsp");
				} else {
					response.sendRedirect("Index.jsp");
				}
			}
		}