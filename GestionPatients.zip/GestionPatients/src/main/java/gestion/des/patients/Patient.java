package gestion.des.patients;

import java.util.*;

public class Patient extends Utilisateur {
   public Patient(String userName, String password) {
		super(userName, password);
		
	}


   private int idPatient;
   
   private String nomPatient;
  
   private String prenomPatient;
   public Patient(String userName, String password, int idPatient, String nomPatient, String prenomPatient, int agePatient,
		String sexePatient, String adressePatient, String telephonePatient) {
	super(userName, password);
	this.idPatient = idPatient;
	this.nomPatient = nomPatient;
	this.prenomPatient = prenomPatient;
	this.agePatient = agePatient;
	this.sexePatient = sexePatient;
	this.adressePatient = adressePatient;
	this.telephonePatient = telephonePatient;
}

public int getIdPatient() {
	return idPatient;
}

public void setIdPatient(int idPatient) {
	this.idPatient = idPatient;
}

public String getNomPatient() {
	return nomPatient;
}

public void setNomPatient(String nomPatient) {
	this.nomPatient = nomPatient;
}

public String getPrenomPatient() {
	return prenomPatient;
}

public void setPrenomPatient(String prenomPatient) {
	this.prenomPatient = prenomPatient;
}

public int getAgePatient() {
	return agePatient;
}

public void setAgePatient(int agePatient) {
	this.agePatient = agePatient;
}

public String getSexePatient() {
	return sexePatient;
}

public void setSexePatient(String sexePatient) {
	this.sexePatient = sexePatient;
}

public String getAdressePatient() {
	return adressePatient;
}

public void setAdressePatient(String adressePatient) {
	this.adressePatient = adressePatient;
}

public String getTelephonePatient() {
	return telephonePatient;
}

public void setTelephonePatient(String telephonePatient) {
	this.telephonePatient = telephonePatient;
}


   private int agePatient;
   private String sexePatient;
   private String adressePatient;
   private String telephonePatient;
   
 
   public void ajouter() {
      // TODO: implement
   }
   
   /** @pdOid 24354b4d-a48e-4082-94f8-7d9513d2fb34 */
   public void modifier() {
      // TODO: implement
   }
   
   /** @pdOid e6dfc2f2-a696-434a-850b-227690bdc7d0 */
   public void supprimer() {
      // TODO: implement
   }
   
   /** @pdOid 03ef9f9f-f7e3-4f4b-9b8a-fdaade4e6f51 */
   public void rechercher() {
      // TODO: implement
   }


}