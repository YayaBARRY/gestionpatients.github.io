package gestion.des.patients;

public class Utilisateur {
   private String userName;
   private String password;
   
   public void creerCompte() {
      
   }
   
   public Utilisateur(String userName, String password) {
	super();
	this.userName = userName;
	this.password = password;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public void modifieCompte() {
 
   }
   
   /** @pdOid 599b3ece-7714-4477-b806-0884d7e6918a */
   public void supprimerCompte() {
     
   }

}