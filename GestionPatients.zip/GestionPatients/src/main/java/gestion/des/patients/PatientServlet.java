package gestion.des.patients;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the patient.
 */

@WebServlet("/Patient")
public class PatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Patient patient;
	
	public void init() {
		patient = new Patient(null, null);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/nouveau":
				showNewForm(request, response);
				break;
			case "/insert":
				insertPatient(request, response);
				break;
			case "/delete":
				deletePatient(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updatePatient(request, response);
				break;
			default:
				listerPatient(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	
	private void listerPatient(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Patient> listUser = patient.getIdPatient();
		request.setAttribute("listerPatient", patient);
		RequestDispatcher dispatcher = request.getRequestDispatcher("PatientManager.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("AjouterModifierPatient.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response, Object existingPatient)
			throws SQLException, ServletException, IOException {
		int idPatient = Integer.parseInt(request.getParameter("idPatient"));
		Patient existingUser = Patient.getidPatient(idPatient);
		RequestDispatcher dispatcher = request.getRequestDispatcher("AjouterModifierPatient.jsp");
		request.setAttribute("patient", existingPatient);
		dispatcher.forward(request, response);

	}

	private void insertPatient(HttpServletRequest request, HttpServletResponse response, Object savePatient) 
			throws SQLException, IOException {
		String nomPatient = request.getParameter("nomPatient");
		String prenomPatient = request.getParameter("prenomPatient");
		String agePatient = request.getParameter("agePatient");
		String sexePatient = request.getParameter("sexePatient");
		String adressePatient = request.getParameter("adressePatient");
		String telephone = request.getParameter("telephonePatient");
		Patient newPatient = new Patient(nomPatient, prenomPatient, agePatient, sexePatient, adressePatient, telephonePatient);
		Patient.savePatient(newPatient);
		response.sendRedirect("lister");
	}

	private void updatePatient(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int idPatient = Integer.parseInt(request.getParameter("idPatient"));
		String nomPatient = request.getParameter("nomPatient");
		String prenomPatient = request.getParameter("prenomPatient");
		String agePatient = request.getParameter("agePatient");
		String sexePatient = request.getParameter("sexePatient");
		String adressePatient = request.getParameter("adressePatient");
		String telephonePatient = request.getParameter("telephonePatient");
        
	
		Patient patient = new Patient(nomPatient, prenomPatient, agePatient, sexePatient, adressePatient, telephonePatient);
		Patient.updatePatient(patient);
		response.sendRedirect("lister");
	}

	private void deletePatient(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int idPatient = Integer.parseInt(request.getParameter("idPatient"));
		Patient.deletePatient(idPatient);
		response.sendRedirect("lister");
	}
}